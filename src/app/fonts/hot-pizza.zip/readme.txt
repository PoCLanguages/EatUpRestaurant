TrueTypeFont: Hot Pizza
Dennis Ludlow  2001 all rights reserved
Sharkshock Productions
maddhatter_dl@yahoo.com

Hi everybody. Sink your teeth into this font fresh from the kitchens of Sharkshock.
Nothing special here, but do note: THIS FONT IS NOT MEANT TO BE USED IN 
ALL CAPS LIKE THIS INSTANT MESSAGE PEOPLE. Other than that, umm.....enjoy!
 This font of course is free for any non commercial use. If you like it, email me and tell me!

check out my graphic archive at www.sharkshock.uni.cc
                                  "Take a bite out of BORING design!"